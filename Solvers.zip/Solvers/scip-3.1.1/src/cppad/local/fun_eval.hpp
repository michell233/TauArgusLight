/* $Id: fun_eval.hpp 2506 2012-10-24 19:36:49Z bradbell $ */
# ifndef CPPAD_FUN_EVAL_INCLUDED
# define CPPAD_FUN_EVAL_INCLUDED

/* --------------------------------------------------------------------------
CppAD: C++ Algorithmic Differentiation: Copyright (C) 2003-06 Bradley M. Bell

CppAD is distributed under multiple licenses. This distribution is under
the terms of the 
                    Eclipse Public License Version 1.0.

A copy of this license is included in the COPYING file of this distribution.
Please visit http://www.coin-or.org/CppAD/ for information on other licenses.
-------------------------------------------------------------------------- */

/*
$begin FunEval$$
$spell
$$

$index evaluate, ADFun$$
$index ADFun, evaluate$$

$section Evaluate ADFun Functions, Derivatives, and Sparsity Patterns$$

$childtable%
	cppad/local/forward.hpp%
	cppad/local/reverse.hpp%
	cppad/local/sparse.hpp
%$$

$end
*/

# include <cppad/local/forward.hpp>
# include <cppad/local/reverse.hpp>
# include <cppad/local/sparse.hpp>

# endif
