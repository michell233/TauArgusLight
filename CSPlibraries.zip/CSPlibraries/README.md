
Argus Open Source

Software to apply Statistical Disclosure Control techniques

Copyright M.D. Montes de Oca & J.J. SALAZAR

This program is free software; you can redistribute it and/or modify it under the termcomboBoxOutputDimensions of the European Union Public Licence (EUPL) version 1.1, as published by the European Commission.

You can find the text of the EUPL v1.1 on https://joinup.ec.europa.eu/software/page/eupl/licence-eupl

This software is distributed on an "AS IS" basis without warranties or conditions of any kind, either express or implied.
